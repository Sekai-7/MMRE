#include "TimelineCache.h"
#include "MultiResourceTimelineCache.h"

class TriggerManager {
public:
    // 触发器类型枚举
    enum class TriggerType {
        TIME_INTERVAL,      // 时间间隔触发
        EVENT_DETECTION,    // 事件检测触发
        DATA_THRESHOLD,     // 数据阈值触发
        MANUAL             // 手动触发
    };

    // 触发器配置结构
    struct TriggerConfig {
        TriggerType type;
        ResourceType data_type;  // 改为使用 DataType
        std::chrono::milliseconds interval;
        std::function<bool(const UnifiedDataPacket&)> detection_func;  // 使用 UnifiedDataPacket
        double threshold_value;
        bool enabled;
    };

private:
    MultiResourceTimelineCache* cache;
    std::map<ResourceType, std::vector<TriggerConfig>> triggers;
    std::map<ResourceType, long long> last_checkpoint_time;
    std::mutex trigger_mutex;

public:
    TriggerManager(MultiResourceTimelineCache* c) : cache(c) {}

    // 注册触发器
    void register_trigger(const TriggerConfig& config) {
        std::lock_guard<std::mutex> lock(trigger_mutex);
        triggers[config.data_type].push_back(config);
    }

    // 检查是否需要创建检查点（数据输入时调用）
    void check_and_create_checkpoint(const UnifiedDataPacket& packet) {
        std::lock_guard<std::mutex> lock(trigger_mutex);
        
        auto trigger_it = triggers.find(packet.type);
        if (trigger_it == triggers.end()) {
            return;
        }

        for (const auto& trigger : trigger_it->second) {
            if (!trigger.enabled) continue;

            bool should_create_checkpoint = false;

            switch (trigger.type) {
                case TriggerType::TIME_INTERVAL:
                    should_create_checkpoint = check_time_interval_trigger(packet, trigger);
                    break;

                case TriggerType::EVENT_DETECTION:
                    should_create_checkpoint = check_event_detection_trigger(packet, trigger);
                    break;

                case TriggerType::DATA_THRESHOLD:
                    should_create_checkpoint = check_threshold_trigger(packet, trigger);
                    break;

                case TriggerType::MANUAL:
                    break;
            }

            if (should_create_checkpoint) {
                create_checkpoint(packet);
                break;
            }
        }
    }

private:
    bool check_time_interval_trigger(const UnifiedDataPacket& packet, const TriggerConfig& config) {
        auto last_time_it = last_checkpoint_time.find(packet.type);
        if (last_time_it == last_checkpoint_time.end()) {
            last_checkpoint_time[packet.type] = packet.timestamp;
            return true;
        }

        auto elapsed = packet.timestamp - last_time_it->second;
        return elapsed >= config.interval.count();
    }

    bool check_event_detection_trigger(const UnifiedDataPacket& packet, const TriggerConfig& config) {
        if (config.detection_func) {
            return config.detection_func(packet);
        }
        return false;
    }

    bool check_threshold_trigger(const UnifiedDataPacket& packet, const TriggerConfig& config) {
        double packet_value = extract_numeric_value(packet);
        return packet_value > config.threshold_value;
    }

    double extract_numeric_value(const UnifiedDataPacket& packet) {
        if (!packet.data_ptr || packet.data_size == 0) {
            return 0.0;
        }

        switch (packet.type) {
            case ResourceType::GPS: {
                // 假设GPS数据格式包含速度信息
                if (packet.data_size >= sizeof(double)) {
                    double* speed_ptr = static_cast<double*>(packet.data_ptr);
                    return *speed_ptr;
                }
                break;
            }
            case ResourceType::IMU: {
                // 假设IMU数据格式包含加速度信息
                if (packet.data_size >= 3 * sizeof(double)) {
                    double* accel_ptr = static_cast<double*>(packet.data_ptr);
                    // 计算加速度模长
                    return sqrt(accel_ptr[0]*accel_ptr[0] + accel_ptr[1]*accel_ptr[1] + accel_ptr[2]*accel_ptr[2]);
                }
                break;
            }
            case ResourceType::VEHICLE_SIGNAL: {
                // 假设车辆信号数据格式
                if (packet.data_size >= sizeof(float)) {
                    float* signal_ptr = static_cast<float*>(packet.data_ptr);
                    return static_cast<double>(*signal_ptr);
                }
                break;
            }
            default:
                return 0.0;
        }
        return 0.0;
    }

    void create_checkpoint(const UnifiedDataPacket& reference_packet) {
        // 直接插入时间戳作为检查点
        bool success = cache->insert_checkpoint(reference_packet.timestamp);
        
        if (success) {
            last_checkpoint_time[reference_packet.type] = reference_packet.timestamp;
            log_info("Created checkpoint at timestamp " + std::to_string(reference_packet.timestamp));
        } else {
            log_error("Failed to create checkpoint at timestamp " + std::to_string(reference_packet.timestamp));
        }
    }

    std::vector<uint8_t> serialize_checkpoint_data(const CheckpointData& data);
    std::string datatype_to_string(ResourceType type);
};