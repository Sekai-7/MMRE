#include <cstdint>
#include <cstddef>


class SharedMemoryHandle {
private:
    uint64_t handle_id;
    void* memory_ptr;
    size_t memory_size;
    bool valid;

public:
    SharedMemoryHandle() : handle_id(0), memory_ptr(nullptr), memory_size(0), valid(false) {}
    
    SharedMemoryHandle(uint64_t id, void* ptr, size_t size) 
        : handle_id(id), memory_ptr(ptr), memory_size(size), valid(true) {}
    
    // 移动语义
    SharedMemoryHandle(SharedMemoryHandle&& other) noexcept 
        : handle_id(other.handle_id), memory_ptr(other.memory_ptr), 
          memory_size(other.memory_size), valid(other.valid) {
        other.valid = false;
    }
    
    SharedMemoryHandle& operator=(SharedMemoryHandle&& other) noexcept {
        if (this != &other) {
            handle_id = other.handle_id;
            memory_ptr = other.memory_ptr;
            memory_size = other.memory_size;
            valid = other.valid;
            other.valid = false;
        }
        return *this;
    }
    
    // 禁用拷贝
    SharedMemoryHandle(const SharedMemoryHandle&) = delete;
    SharedMemoryHandle& operator=(const SharedMemoryHandle&) = delete;
    
    bool is_valid() const { return valid; }
    void* get_ptr() const { return memory_ptr; }
    size_t get_size() const { return memory_size; }
    uint64_t get_id() const { return handle_id; }
};