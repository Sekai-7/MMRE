#ifndef COMMON_H
#define COMMON_H

#include "SharedMemoryManager.h"

#include <memory>
#include <variant>
// #include <chrono>

using Timestamp = long long;
using Handle = std::variant<void*, SharedMemoryHandle>;

// 枚举表示数据类型
enum class ResourceType {
    CAMERA,
    AUDIO,
    GPS,
    IMU,
    VEHICLE_SIGNAL
    // ... 其他数据类型
};

// 统一数据包结构
struct UnifiedDataPacket {
    Timestamp timestamp;
    ResourceType type;
    // void* data_ptr; // 指向共享内存的指针
    Handle data_ptr;
    size_t data_size;

    void* get_ptr() {
        struct Visitor {
            void* operator() (void* ptr) {
                return ptr; 
            }
            void* operator() (SharedMemoryHandle& handle) {
                if (handle.is_valid() == false || handle.get_size() == 0)
                    return nullptr;
                return handle.get_ptr();
            }
        };
        return std::visit(Visitor{}, data_ptr);
    }

    const void* get_ptr() const {
        struct Visitor {
            void* operator() (void* ptr) const {
                return ptr; 
            }
            void* operator() (const SharedMemoryHandle& handle) const {
                if (handle.is_valid() == false || handle.get_size() == 0)
                    return nullptr;
                return handle.get_ptr();
            }
        };
        return std::visit(Visitor{}, data_ptr);
    }

    UnifiedDataPacket() : timestamp(0), type(ResourceType::CAMERA), data_ptr(nullptr), data_size(0) {} // 添加默认构造函数
    UnifiedDataPacket(Timestamp ts, ResourceType t, void* ptr, size_t size) : timestamp(ts), type(t), data_ptr(ptr), data_size(size) {} // 添加构造函数

    UnifiedDataPacket(const UnifiedDataPacket& other) = delete;
    UnifiedDataPacket& operator=(const UnifiedDataPacket& other) = delete;
    // UnifiedDataPacket(const UnifiedDataPacket& other) {
    //     this->timestamp = other.timestamp;
    //     this->type = other.type;
    //     this->data_size = other.data_size;
    //     if (std::get_if<SharedMemoryHandle>(&other.data_ptr)) {
            
    //     }

    // }
    // UnifiedDataPacket& operator=(const UnifiedDataPacket& other) {
    //     this->timestamp = other.timestamp;
    //     this->type = other.type;
    //     this->data_size = other.data_size;
    //     this->data_ptr = std::move(other.data_ptr);

    // }

    UnifiedDataPacket(UnifiedDataPacket&& other) {
        this->timestamp = other.timestamp;
        this->type = other.type;
        this->data_size = other.data_size;
        this->data_ptr = std::move(other.data_ptr);
        return;
    }

    UnifiedDataPacket& operator=(UnifiedDataPacket&& other) {
        if (&other == this)
            return *this;
        this->timestamp = other.timestamp;
        this->type = other.type;
        this->data_size = other.data_size;
        this->data_ptr = std::move(other.data_ptr);
        return *this;
    }

    // 拷贝构造函数 (深拷贝共享内存)
    // UnifiedDataPacket(const UnifiedDataPacket& other) : timestamp(other.timestamp), type(other.type), data_size(other.data_size) {}

    // 赋值运算符重载 (深拷贝共享内存)
    // UnifiedDataPacket& operator=(const UnifiedDataPacket& other) {}

    // 析构函数 (释放共享内存)
    ~UnifiedDataPacket() {}
};
#endif