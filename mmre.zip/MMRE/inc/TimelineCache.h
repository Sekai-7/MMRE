#ifndef TIMELINECACHE_H
#define TIMELINECACHE_H

// #include "SharedMemoryManager.h"
#include "common.h"

#include <sys/mman.h>

#include <iostream>
#include <map>
#include <deque>
#include <vector>
#include <atomic>
#include <memory>
#include <stdexcept>
#include <algorithm>
#include <thread>
#include <mutex>
#include <variant>


#include <cstdlib>
#include <cstring>
#include <climits>
#include <cstring>


struct CacheNode;
struct CacheNodePool;




// find出来的数据是否会被修改呢？
// 还是只是需要拿到数据？
// class TimelineCacheBaseLine {
// private:
//     std::map<Timestamp, std::shared_ptr<UnifiedDataPacket>> data_map;
//     std::deque<Timestamp> data_deque;

//     std::mutex mtx;

// public:
//     void insert(Timestamp, ResourceType, void*, size_t);

//     std::shared_ptr<UnifiedDataPacket> find(Timestamp);

//     std::vector<std::shared_ptr<UnifiedDataPacket>> query_range(Timestamp, Timestamp);

//     std::shared_ptr<UnifiedDataPacket> evict_oldest();

//     void clear();
    
//     ~TimelineCacheBaseLine() {}
// };

// ------------------ TimelineCache ------------------
class TimelineCache {
private:
    std::mutex mtx;

    CacheNode* root;
    CacheNode* list_head;
    CacheNode* list_tail;

    Timestamp current_size;
    Timestamp current_memory_usage;

    std::unique_ptr<CacheNodePool> node_pool;

    Timestamp min_timestamp;
    Timestamp max_timestamp;

    // --- AVL 辅助 ---
    static int get_height(CacheNode* n);
    static int get_balance_factor(CacheNode* n);
    static void update_height(CacheNode* n);

    CacheNode* rotate_left(CacheNode* x);
    CacheNode* rotate_right(CacheNode* y);
    CacheNode* rebalance(CacheNode* n);

    CacheNode* insert(CacheNode* node, Timestamp ts, UnifiedDataPacket&& packet, CacheNode*& inserted);
    CacheNode* remove_pureAVL(CacheNode* node, Timestamp ts, CacheNode*& deleted_node);

    void query_range(CacheNode* node, Timestamp, Timestamp, std::vector<UnifiedDataPacket*>& out) const;

    void destroy(CacheNode* node);
    CacheNode* find_node(Timestamp ts) const;

    CacheNode* find_predecessor(Timestamp ts) const;
    CacheNode* find_successor(Timestamp ts) const;

    void link_into_list(CacheNode* node);
    void unlink_from_list(CacheNode* node);
    void relink_into_list(CacheNode* node);

    void refresh_min_max_after_change();

public:
    explicit TimelineCache();
    ~TimelineCache();

    void clear();

    void insert(UnifiedDataPacket&& packet);
    bool remove(Timestamp timestamp);
    UnifiedDataPacket* query(Timestamp timestamp);
    std::vector<UnifiedDataPacket*> query_by_range(Timestamp start_ts, Timestamp end_ts);

    // UnifiedDataPacket evict_oldest();
    // UnifiedDataPacket evict_newest();

    Timestamp get_min_timestamp() const;
    Timestamp get_max_timestamp() const;

    long long size();
    long long memory_usage();
};

#endif