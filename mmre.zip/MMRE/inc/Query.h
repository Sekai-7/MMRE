#include "MultiResourceTimelineCache.h"

class QueryDataProcessor;

class ResponseFormatter;

class QueryRequest;


struct NativeQueryRequest {
    std::string device_type;           // "camera", "vehicle_signal", "gps", "imu"
    std::string query_type;            // "time_range", "timestamp", "event", "pattern"
    std::map<std::string, std::variant<long long, std::string, double>> parameters;
    QueryOptions options;
    
    // 后处理标识
    bool need_post_processing = false;
    std::string post_processing_type;  // "text_only", "explainable", "compress", etc.
    std::map<std::string, std::string> post_processing_params;
};

// 内部查询响应
struct NativeQueryResponse {
    bool success;
    std::string error_message;
    UniversalQueryResult query_result;
};

// 最终响应（经过后处理）
struct FinalQueryResponse {
    bool success;
    std::string error_message;
    std::string response_data;  // 序列化后的数据
    std::map<std::string, std::string> metadata;
    FinalQueryResponse() {}
    explicit FinalQueryResponse(const NativeQueryResponse&) {}
}; 

// class InterfaceParser;
class InterfaceParser {
public:
    // 统一的解析入口
    static std::pair<NativeQueryRequest, bool> parse_request(const QueryRequest& original_request);

private:
    static std::pair<NativeQueryRequest, bool> parse_ipc_request(const QueryRequest& request);

    static std::pair<NativeQueryRequest, bool> parse_rpc_request(const QueryRequest& request);

    static std::pair<NativeQueryRequest, bool> parse_sql_request(const QueryRequest& request);

    static std::pair<NativeQueryRequest, bool> parse_native_request(const QueryRequest& request);

    // 确定是否需要后处理, 可以直接在request发起的时候用一个字段来确认，或者扩展为更丰富的规则等等，现在是一个示例。确认之后在格式化的请求中标注。
    static void determine_post_processing_needs(NativeQueryRequest& native_req);
    
    static std::vector<std::string> split_string(const std::string& str, char delimiter);
    
    static std::variant<long long, std::string, double> parse_value(const std::string& value);
};

class BaseQuery {
protected:
    MultiResourceTimelineCache* cache;
private:
    std::unique_ptr<QueryDataProcessor> data_processor;
    std::unique_ptr<ResponseFormatter> response_formatter;
public:
    BaseQuery(MultiResourceTimelineCache* c) : cache(c) {
        // need complete
    }

    FinalQueryResponse handle_query(const QueryRequest&);

    virtual ~BaseQuery() = default;
protected:
    virtual NativeQueryResponse execute_native_query(const NativeQueryRequest&) = 0;
};

class CameraQuery : public BaseQuery {
public:
    CameraQuery(MultiResourceTimelineCache* c) : BaseQuery(c) {}

protected:
    NativeQueryResponse execute_native_query(const NativeQueryRequest& request) override;
};


class VehicleSignalQuery : public BaseQuery {
public:
    VehicleSignalQuery(MultiResourceTimelineCache* c) : BaseQuery(c) {}

protected:
    NativeQueryResponse execute_native_query(const NativeQueryRequest& request) override;
};