#include "MultiResourceTimelineCache.h"

class QueryDataProcessor;

class ResponseFormatter;

class QueryRequest;

<<<<<<< Updated upstream
class NativeQueryResponse;

class NativeQueryRequest;

class FinalQueryResponse;
=======
struct NativeQueryRequest {
    std::string device_type;           // "camera", "vehicle_signal", "gps", "imu"
    std::string query_type;            // "time_range", "timestamp", "event", "pattern"
    std::map<std::string, std::variant<long long, std::string, double>> parameters;
    QueryOptions options;
    
    // 后处理标识
    bool need_post_processing = false;
    std::string post_processing_type;  // "text_only", "explainable", "compress", etc.
    std::map<std::string, std::string> post_processing_params;
};

// 内部查询响应
struct NativeQueryResponse {
    bool success;
    std::string error_message;
    UniversalQueryResult query_result;
};

// 最终响应（经过后处理）
struct FinalQueryResponse {
    bool success;
    std::string error_message;
    std::string response_data;  // 序列化后的数据
    std::map<std::string, std::string> metadata;
    FinalQueryResponse() {}
    explicit FinalQueryResponse(const NativeQueryResponse&) {}
}; 
>>>>>>> Stashed changes

class InterfaceParser;

class BaseQuery {
private:
    MultiResourceTimelineCache* cache;
    std::unique_ptr<QueryDataProcessor> data_processor;
    std::unique_ptr<ResponseFormatter> response_formatter;
public:
    BaseQuery(MultiResourceTimelineCache* c) : cache(c) {
        // need complete
    }

    FinalQueryResponse handle_query(const QueryRequest&);

    virtual ~BaseQuery() = default;
protected:
<<<<<<< Updated upstream
    virtual NativeQueryResponse execute_native_query(const NativeQueryRequest) = 0;
=======
    virtual NativeQueryResponse execute_native_query(const NativeQueryRequest&) = 0;
};

class CameraQuery : public BaseQuery {
public:
    CameraQuery(MultiResourceTimelineCache* c) : BaseQuery(c) {}

protected:
    NativeQueryResponse execute_native_query(const NativeQueryRequest& request) override;

private:
};


class VehicleSignalQuery : public BaseQuery {
public:
    VehicleSignalQuery(MultiResourceTimelineCache* c) : BaseQuery(c) {}

protected:
    NativeQueryResponse execute_native_query(const NativeQueryRequest& request) override {
        NativeQueryResponse response;
        
        try {
            if (request.query_type == "time_range") {
                auto start_time = std::get<long long>(request.parameters.at("start_time"));
                auto end_time = std::get<long long>(request.parameters.at("end_time"));
                
                auto raw_result = cache->query_by_range(ResourceType::VEHICLE_SIGNAL, start_time, end_time);
                response.query_result = convert_to_universal_result(raw_result, DataType::VEHICLE_SIGNAL);
                response.success = true;
            }
            
        } catch (const std::exception& e) {
            response.success = false;
            response.error_message = "Vehicle signal query error: " + std::string(e.what());
        }
        
        return response;
    }
>>>>>>> Stashed changes
};