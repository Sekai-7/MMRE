#include "TriggerManager.h"

void TriggerManager::register_trigger(const TriggerConfig& config) {
    std::lock_guard<std::mutex> lock(trigger_mutex);
    triggers[config.resource_type].push_back(config);
    return;
}

void TriggerManager::check_and_create_checkpoint(const UnifiedDataPacket& packet) {
    std::lock_guard<std::mutex> lock(trigger_mutex);
    
    auto trigger_it = triggers.find(packet.type);
    if (trigger_it == triggers.end()) {
        return;
    }

    for (const auto& trigger : trigger_it->second) {
        if (!trigger.enabled) continue;

        bool should_create_checkpoint = false;

        switch (trigger.type) {
            case TriggerType::TIME_INTERVAL:
                should_create_checkpoint = check_time_interval_trigger(packet, trigger);
                break;

            case TriggerType::EVENT_DETECTION:
                should_create_checkpoint = check_event_detection_trigger(packet, trigger);
                break;

            case TriggerType::DATA_THRESHOLD:
                should_create_checkpoint = check_threshold_trigger(packet, trigger);
                break;

            case TriggerType::MANUAL:
                break;
        }

        if (should_create_checkpoint) {
            create_checkpoint(packet);
            break;
        }
    }
}