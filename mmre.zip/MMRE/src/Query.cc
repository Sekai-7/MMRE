#include "Query.h"

FinalQueryResponse BaseQuery::handle_query(const QueryRequest& request) {
<<<<<<< Updated upstream
     
} 
=======
    // 步骤1: 解析四种接口格式为统一的native格式
    auto [native_request, parse_success] = InterfaceParser::parse_request(original_request);
    
    if (!parse_success) {
        FinalQueryResponse error_response;
        error_response.success = false;
        error_response.error_message = "Failed to parse request";
        return error_response;
    }

    // 步骤2: 执行统一的查询逻辑
    auto native_response = execute_native_query(native_request);
    
    if (!native_response.success) {
        // 这里为什么要传入接口类型？query完成之后我们还需要关注接口类型吗？
        // 这里为什么要设计convert_to_final_response作为数据成员？他的设计貌似也不是一个函数对象
        // 为什么要设计FinalQueryResponse和NativeQueryResponse两个数据结构？
        // 能不能合为一个？
        // return convert_to_final_response(native_response, original_request.interface_type);
        return FinalQueryResponse(native_response);
    }

    // 步骤3: 判断是否需要后处理
    if (native_request.need_post_processing) {
        native_response.query_result = data_processor->process(
            native_response.query_result,
            native_request.post_processing_type,
            native_request.device_type,
            native_request.post_processing_params
        );
    }

    // 步骤4: 格式化响应
    // return convert_to_final_response(native_response, original_request.interface_type);   
    return FinalQueryResponse(native_response);
} 

NativeQueryResponse CameraQuery::execute_native_query(const NativeQueryRequest& request) override {
        NativeQueryResponse response;
        
        try {
            if (request.query_type == "time_range") {
                auto start_time = std::get<long long>(request.parameters.at("start_time"));
                auto end_time = std::get<long long>(request.parameters.at("end_time"));
                
                auto raw_result = cache->query_by_range(ResourceType::CAMERA, start_time, end_time);
                response.query_result = convert_to_universal_result(raw_result, DataType::CAMERA);
                response.success = true;
                
            } else if (request.query_type == "timestamp") {
                auto timestamp = std::get<long long>(request.parameters.at("timestamp"));
                
                auto raw_result = cache->query_by_range(ResourceType::CAMERA, timestamp - 100, timestamp + 100);
                response.query_result = convert_to_universal_result(raw_result, DataType::CAMERA);
                response.success = true;
            }
            
        } catch (const std::exception& e) {
            response.success = false;
            response.error_message = "Camera query error: " + std::string(e.what());
        }
        
        return response;
}
>>>>>>> Stashed changes
