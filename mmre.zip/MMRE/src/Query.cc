#include "Query.h"

FinalQueryResponse BaseQuery::handle_query(const QueryRequest& request) {
    // 步骤1: 解析四种接口格式为统一的native格式
    auto [native_request, parse_success] = InterfaceParser::parse_request(original_request);
    
    if (!parse_success) {
        FinalQueryResponse error_response;
        error_response.success = false;
        error_response.error_message = "Failed to parse request";
        return error_response;
    }

    // 步骤2: 执行统一的查询逻辑
    auto native_response = execute_native_query(native_request);
    
    if (!native_response.success) {
        // 这里为什么要传入接口类型？query完成之后我们还需要关注接口类型吗？
        // 这里为什么要设计convert_to_final_response作为数据成员？他的设计貌似也不是一个函数对象
        // 为什么要设计FinalQueryResponse和NativeQueryResponse两个数据结构？
        // 能不能合为一个？
        // return convert_to_final_response(native_response, original_request.interface_type);
        return FinalQueryResponse(native_response);
    }

    // 步骤3: 判断是否需要后处理
    if (native_request.need_post_processing) {
        native_response.query_result = data_processor->process(
            native_response.query_result,
            native_request.post_processing_type,
            native_request.device_type,
            native_request.post_processing_params
        );
    }

    // 步骤4: 格式化响应
    // return convert_to_final_response(native_response, original_request.interface_type);   
    return FinalQueryResponse(native_response);
} 

NativeQueryResponse CameraQuery::execute_native_query(const NativeQueryRequest& request) {
        NativeQueryResponse response;
        
        try {
            if (request.query_type == "time_range") {
                auto start_time = std::get<long long>(request.parameters.at("start_time"));
                auto end_time = std::get<long long>(request.parameters.at("end_time"));
                
                auto raw_result = cache->query_by_range(ResourceType::CAMERA, start_time, end_time);
                response.query_result = convert_to_universal_result(raw_result, ResourceType::CAMERA);
                response.success = true;
                
            } else if (request.query_type == "timestamp") {
                auto timestamp = std::get<long long>(request.parameters.at("timestamp"));
                
                auto raw_result = cache->query_by_range(ResourceType::CAMERA, timestamp - 100, timestamp + 100);
                response.query_result = convert_to_universal_result(raw_result, ResourceType::CAMERA);
                response.success = true;
            }
            
        } catch (const std::exception& e) {
            response.success = false;
            response.error_message = "Camera query error: " + std::string(e.what());
        }
        
        return response;
}

NativeQueryResponse VehicleSignalQuery::execute_native_query(const NativeQueryRequest& request) {
    NativeQueryResponse response;
    
    try {
        if (request.query_type == "time_range") {
            auto start_time = std::get<long long>(request.parameters.at("start_time"));
            auto end_time = std::get<long long>(request.parameters.at("end_time"));
            
            auto raw_result = cache->query_by_range(ResourceType::VEHICLE_SIGNAL, start_time, end_time);
            response.query_result = convert_to_universal_result(raw_result, ResourceType::VEHICLE_SIGNAL);
            response.success = true;
        }
        
    } catch (const std::exception& e) {
        response.success = false;
        response.error_message = "Vehicle signal query error: " + std::string(e.what());
    }
    
    return response;
}

std::pair<NativeQueryRequest, bool> InterfaceParser::parse_request(const QueryRequest& original_request) {
    NativeQueryRequest native_request;
    bool parse_success = false;
    
    switch (original_request.interface_type) {
        case InterfaceType::IPC:
            std::tie(native_request, parse_success) = parse_ipc_request(original_request);
            break;
        case InterfaceType::RPC:
            std::tie(native_request, parse_success) = parse_rpc_request(original_request);
            break;
        case InterfaceType::SQL:
            std::tie(native_request, parse_success) = parse_sql_request(original_request);
            break;
        case InterfaceType::NATIVE:
            std::tie(native_request, parse_success) = parse_native_request(original_request);
            break;
    }
    
    // 解析后处理需求
    if (parse_success) {
        determine_post_processing_needs(native_request);
    }
    
    return {native_request, parse_success};
}

void InterfaceParser::determine_post_processing_needs(NativeQueryRequest& native_req) {
    // 规则1: camera + text_only参数 -> 需要文本后处理
    if (native_req.device_type == "camera") {
        auto text_only_it = native_req.parameters.find("text_only");
        if (text_only_it != native_req.parameters.end() && 
            std::get<std::string>(text_only_it->second) == "true") {
            native_req.need_post_processing = true;
            native_req.post_processing_type = "text_only";
        }
    }
    
    // 规则2: vehicle_signal + explainable参数 -> 需要可解释性后处理
    if (native_req.device_type == "vehicle_signal") {
        auto explainable_it = native_req.parameters.find("explainable");
        if (explainable_it != native_req.parameters.end() && 
            std::get<std::string>(explainable_it->second) == "true") {
            native_req.need_post_processing = true;
            native_req.post_processing_type = "explainable";
        }
    }
    
    // 规则3: 根据options判断
    if (native_req.options.require_explanation) {
        native_req.need_post_processing = true;
        if (native_req.post_processing_type.empty()) {
            native_req.post_processing_type = "explainable";
        }
    }
}

std::vector<std::string> InterfaceParser::split_string(const std::string& str, char delimiter) {
    std::vector<std::string> result;
    std::stringstream ss(str);
    std::string item;
    while (std::getline(ss, item, delimiter)) {
        result.push_back(item);
    }
    return result;
}

std::variant<long long, std::string, double> InterfaceParser::parse_value(const std::string& value) {
    // 尝试解析为数字
    try {
        if (value.find('.') != std::string::npos) {
            return std::stod(value);
        } else {
            return std::stoll(value);
        }
    } catch (...) {
        return value;  // 作为字符串返回
    }
}