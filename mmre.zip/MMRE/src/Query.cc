#include "Query.h"
#include "MultiResourceTimelineCache.h"

#include <iomanip>
#include <sstream>


QueryResult BaseQuery::handle_query(QueryRequest& request) {
    InterfaceParser::parse_request(request);

    return execute_native_query(request);
} 

QueryResult CameraQuery::execute_native_query(const QueryRequest& request) {
        QueryResult response;

        const auto& parameter = request.parameter;
        
        if (request.query_type == QueryType::TimeRange) {
            auto it_start = parameter.find("start_time");
            auto it_end = parameter.find("end_time");
            if (it_start != parameter.end() && it_end != parameter.end()) {
                const auto& start_time = std::get_if<Timestamp>(&it_start->second);
                const auto& end_time = std::get_if<Timestamp>(&it_end->second);
                if (start_time != nullptr && end_time != nullptr)
                    response = cache->query_by_range(ResourceType::CAMERA, *start_time, *end_time);
            }
        } else if (request.query_type == QueryType::Timestamp) {
            auto it_timestamp = parameter.find("timestamp");
            if (it_timestamp != parameter.end()) {
                const auto& timestamp = std::get_if<Timestamp>(&it_timestamp->second);
                if (timestamp != nullptr)
                    response = cache->query(ResourceType::CAMERA, *timestamp);
            }
        }
            
        return response;
}

QueryResult VehicleSignalQuery::execute_native_query(const QueryRequest& request) {
    QueryResult response;

    const auto& parameter = request.parameter;

    if (request.query_type == QueryType::TimeRange) {
        auto it_start = parameter.find("start_time");
        auto it_end = parameter.find("end_time");
        if (it_start != parameter.end() && it_end != parameter.end()) {
            const auto& start_time = std::get_if<Timestamp>(&it_start->second);
            const auto& end_time = std::get_if<Timestamp>(&it_end->second);
            if (start_time != nullptr && end_time != nullptr)
                response = cache->query_by_range(ResourceType::CAMERA, *start_time, *end_time);
        }
    }
    
    return response;
}

void InterfaceParser::parse_request(QueryRequest& original_request) {
    // 如果是Native, 直接返回
    if (original_request.interface_type == InterfaceType::NATIVE) {
        return;
    }
    
    switch (original_request.interface_type) {
        case InterfaceType::IPC:
            parse_ipc_request(original_request);
            break;
        case InterfaceType::RPC:
            parse_rpc_request(original_request);
            break;
        case InterfaceType::SQL:
            parse_sql_request(original_request);
            break;
    }
}

void InterfaceParser::parse_ipc_request(QueryRequest& request) {

}

void InterfaceParser::parse_rpc_request(QueryRequest& request) {

}

void InterfaceParser::parse_sql_request(QueryRequest& request) {

}

void InterfaceParser::parse_native_request(QueryRequest& request) {

}